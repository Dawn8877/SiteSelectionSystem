# -*- coding: utf-8 -*-
import arcpy

def Model_Parameter():
   
    arcpy.env.overwriteOutput = True
    distance = arcpy.GetParameterAsText(0)

    mc_wetlands = "D:\\GeoDS\\7305\\lab\\Lab04_data\\ModelBuilderGDB_Lab4.gdb\\mc_wetlands"
    mc_major_roads = "D:\\GeoDS\\7305\\lab\\Lab04_data\\ModelBuilderGDB_Lab4.gdb\\mc_major_roads"
    
    mc_major_roads_Buffer = "D:\\ArcGISPro\\Arcgispro_Doc\\7305lab4\\7305lab4.gdb\\mc_major_roads_Buffer"
    Output_Clip = "D:\\ArcGISPro\\Arcgispro_Doc\\7305lab4\\7305lab4.gdb\\mc_wetlands_Clip"

    arcpy.analysis.Buffer(in_features=mc_major_roads, 
                          out_feature_class=mc_major_roads_Buffer, 
                          buffer_distance_or_field=distance)

    arcpy.analysis.Clip(in_features=mc_wetlands, 
                        clip_features=mc_major_roads_Buffer, 
                        out_feature_class=Output_Clip)

if __name__ == '__main__':
    Model_Parameter()