import arcpy

# 你的实际文件夹路径
my_folder = r"D:\GeoDS\7305\lab\Lab05_data\Lab05_data"

# 设置环境设置
arcpy.env.workspace = my_folder
arcpy.env.scratchWorkspace = my_folder
arcpy.env.overwriteOutput = True

# 定义变量
in_feature = "monroe_county_wetlands.shp"
clip_feature = "Buffer.shp"
out_feature = "wetlands_clip_1.shp"
xy_tolerance = ""

# 使用变量执行剪切工具
arcpy.analysis.Clip(in_feature, clip_feature, out_feature, xy_tolerance)

print("Finished clip process!")