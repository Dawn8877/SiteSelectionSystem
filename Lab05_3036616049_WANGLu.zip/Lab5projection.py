import arcpy

# 
arcpy.env.workspace = r"D:\GeoDS\7305\lab\Lab05_data\Lab05_data"
arcpy.env.overwriteOutput = True

in_dataset = "route_stops.shp"

# 
coord_sys = arcpy.SpatialReference(102739)

try:
    # 
    arcpy.management.DefineProjection(in_dataset, coord_sys)
    print("Assignment: Projection defined using code 102739.")
    print(arcpy.GetMessages(0))
except Exception as e:
    print(f"Error: {e}")