import arcpy
import os

# ==========================================
# 1. Workspace Configuration
# ==========================================
PATH_LAB = r'D:\GeoDS\7305\lab\Lab6_data\Lab6_data\Lab06_data'
PATH_ASSIGN = r'D:\GeoDS\7305\lab\Lab6_data\Lab6_data\Assignment_data'

def prepare_env(path):
    """Set workspace and ensure output directory exists"""
    arcpy.env.workspace = path
    arcpy.env.overwriteOutput = True
    res_dir = os.path.join(path, "Results")
    if not os.path.exists(res_dir):
        os.makedirs(res_dir)
    print(f"\n--- Workspace set to: {os.path.basename(path)} ---")

# ==========================================
# 2. Lab Exercises (1.1 - 2.4)
# ==========================================
prepare_env(PATH_LAB)

# --- 1.1-1.3 Selection and Query ---
arcpy.management.MakeFeatureLayer('mc_wetlands.shp', 'wetlands_lyr')
arcpy.management.MakeFeatureLayer('zip.shp', 'zip_lyr')

arcpy.management.SelectLayerByLocation('wetlands_lyr', 'CONTAINS', 'zip_lyr')
arcpy.management.SelectLayerByAttribute('wetlands_lyr', 'SUBSET_SELECTION', 'AREA >= 300000')
arcpy.management.CopyFeatures('wetlands_lyr', 'Results/wetlands_combined.shp')
print("Lab Selection Tasks: Done")

# --- 2.1-2.4 Data Management ---
fc_ny = "New_York_State.shp"
if arcpy.Exists(fc_ny):
    with arcpy.da.UpdateCursor(fc_ny, ["NAME"], "NAME = 'Albany'") as cursor:
        for row in cursor:
            row[0] = "Albany-NYS"
            cursor.updateRow(row)
    
    valid_field = arcpy.ValidateFieldName("NEW FID")
    if not arcpy.ListFields(fc_ny, valid_field):
        arcpy.management.AddField(fc_ny, valid_field, "TEXT", field_length=12)
    print("Lab Data Management Tasks: Done")

# ==========================================
# 3. Assignment Exercises (Ex01 - Ex04)
# ==========================================
prepare_env(PATH_ASSIGN)

# --- Ex 01: Spatial Join/Select ---
school_fc = "EDU_Schools.shp"
buffer_fc = "Buffer.shp"

if arcpy.Exists(school_fc) and arcpy.Exists(buffer_fc):
    arcpy.management.MakeFeatureLayer(school_fc, "edu_school_lyr")
    arcpy.management.SelectLayerByLocation("edu_school_lyr", "COMPLETELY_WITHIN", buffer_fc)
    
    print("Ex01 Schools List:")
    fields = ["SCHOOL", "NY_ADDR", "SHAPE@XY"]
    with arcpy.da.SearchCursor("edu_school_lyr", fields) as cursor:
        for row in cursor:
            print(f"Name: {row[0]} | Addr: {row[1]} | XY: {row[2]}")
else:
    print("Ex01 Warning: Missing Assignment files!")

# --- Ex 03: Conditional Buffering ---
college_fc = "EDU_Colleges.shp"
if arcpy.Exists(college_fc):
    arcpy.analysis.Select(college_fc, "Results/Pub_Col.shp", "TYPE = 'Public'")
    arcpy.analysis.Buffer("Results/Pub_Col.shp", "Results/Pub_Buffer_1500.shp", "1500 METERS")
    
    arcpy.analysis.Select(college_fc, "Results/Pri_Col.shp", "TYPE = 'Private'")
    arcpy.analysis.Buffer("Results/Pri_Col.shp", "Results/Pri_Buffer_750.shp", "750 METERS")
    print("Ex03 Buffer Tasks: Done")

# --- Ex 04: Attribute Population ---
if arcpy.Exists(college_fc):
    pub_field = "PUBLIC"
    if not arcpy.ListFields(college_fc, pub_field):
        arcpy.management.AddField(college_fc, pub_field, "TEXT", field_length=10)

    with arcpy.da.UpdateCursor(college_fc, ["TYPE", pub_field]) as cursor:
        for row in cursor:
            if row[0] == 'Public':
                row[1] = 'YES'
            else:
                row[1] = 'NO'
            cursor.updateRow(row)
            
    print("Ex04 Field Population: Done")

print("\n--- All processes complete ---")