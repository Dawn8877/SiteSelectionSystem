import arcpy

# 1. 获取用户在 ArcGIS Pro 界面上选择的图层 
# 参数 0 对应你设置的第一个参数 (Input Schools)
# 参数 1 对应你设置的第二个参数 (Boundary Buffer)
input_layer = arcpy.GetParameterAsText(0)    
boundary_layer = arcpy.GetParameterAsText(1) 

# 2. 空间查询逻辑
# 先创建一个临时图层
arcpy.management.MakeFeatureLayer(input_layer, "temp_lyr")

# 执行按位置选择：找出在缓冲区内的学校 [cite: 82]
arcpy.management.SelectLayerByLocation("temp_lyr", "COMPLETELY_WITHIN", boundary_layer)

# 3. 提取信息并使用 AddMessage 输出 
# 注意：Ex02 必须使用 AddMessage 才能在 Pro 的消息窗口看到结果
fields = ["SCHOOL", "NY_ADDR", "SHAPE@XY"]

arcpy.AddMessage("--- Searching for schools within buffer ---")

with arcpy.da.SearchCursor("temp_lyr", fields) as cursor:
    count = 0
    for row in cursor:
        # 打印到 Geoprocessing 的 Messages 窗口 
        arcpy.AddMessage(f"School Name: {row[0]}")
        arcpy.AddMessage(f"Address: {row[1]}")
        arcpy.AddMessage(f"Coordinates: {row[2]}")
        arcpy.AddMessage("-" * 15)
        count += 1

if count == 0:
    arcpy.AddMessage("No schools found within the buffer.")
else:
    arcpy.AddMessage(f"Successfully found {count} schools.")